from project.knight import Knight


class DarkKnight(Knight):
    pass